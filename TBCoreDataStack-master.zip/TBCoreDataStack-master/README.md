TBCoreDataStack
===============

Example Core Data Stacks from [blog post](http://robots.thoughtbot.com/core-data)
