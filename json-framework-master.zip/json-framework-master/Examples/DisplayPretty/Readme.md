## Display Pretty

This example contains two text boxes. Input JSON into the left one, and
have it reformatted into the right one when you hit Enter.
